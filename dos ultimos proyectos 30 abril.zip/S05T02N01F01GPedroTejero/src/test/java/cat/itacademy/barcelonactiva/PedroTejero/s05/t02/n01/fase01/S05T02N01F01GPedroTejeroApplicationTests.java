package cat.itacademy.barcelonactiva.PedroTejero.s05.t02.n01.fase01;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class S05T02N01F01GPedroTejeroApplicationTests {

	@Test
	void contextLoads() {
	}

}
