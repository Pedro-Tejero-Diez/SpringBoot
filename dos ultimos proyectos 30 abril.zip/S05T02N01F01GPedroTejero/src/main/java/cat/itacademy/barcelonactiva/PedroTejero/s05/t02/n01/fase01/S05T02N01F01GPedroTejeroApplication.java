package cat.itacademy.barcelonactiva.PedroTejero.s05.t02.n01.fase01;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class S05T02N01F01GPedroTejeroApplication {

	public static void main(String[] args) {
		SpringApplication.run(S05T02N01F01GPedroTejeroApplication.class, args);
	}

}
