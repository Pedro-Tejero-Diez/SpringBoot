package S05T02N01F02GPedroTejero;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class S05T02N01F02GPedroTejeroApplicationTests {

	@Test
	void contextLoads() {
	}

}
